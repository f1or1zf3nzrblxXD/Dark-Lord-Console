# DARK LORD 6.0 - Scam Destroyer

## Description

DARK LORD 6.0 is a batch script tool designed to help users manage webhooks, check links, and perform various utility tasks. This script includes multiple features that enhance the control and security of online activities. The icon is changed by Resource Hacker.

## Features
🤑🤑🤑
- Send Messages via Webhook
- Delete Webhooks
- Rename Webhooks
- Change Webhook Images
- Fun Commands Section
- Change Console Color
- Token Checker
- Set Discord Presence
- Fake Link Checker
- Logs user actions for reference

## Usage
🤓🤓🤓
1. Run DarkLord6.0.exe to start the program.
2. Navigate through the menu using the listed options.
3. Select an option by entering the corresponding number.
4. Follow on-screen instructions for each command.

## Log File
🤑🤑🤑
A `log.txt` file is automatically created to record user selections and actions for reference.

## Disclaimer
🤍🤍🤍
This tool is created for educational and security purposes only. The developer is not responsible for any misuse or damage caused by this software.

## Credits
❤️🤍🖤
Developed by DARK LORD Dev Team. if you encounter any problems, add me on discord: f1or1zf3nzrblx

